#!/usr/bin/env python3
"""
RF Scanner Web Server
Serves the interactive heat-map web UI and REST API.
"""

import io
import json
import os
import sqlite3
import statistics
import sys
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory, abort
from flask_cors import CORS

# ── Ensure server/ directory is on the path so export.py can be imported ─────
SERVER_DIR = Path(__file__).parent.resolve()
if str(SERVER_DIR) not in sys.path:
    sys.path.insert(0, str(SERVER_DIR))

from export import export_bp   # noqa: E402 — must come after sys.path fix

# ── Paths — all relative to this file so they work from any cwd ───────────────
BASE_DIR     = SERVER_DIR.parent
DB_PATH      = Path(os.environ.get("RF_SCANNER_DB", str(BASE_DIR / "data" / "scans.db")))
STATIC_DIR   = BASE_DIR / "static"
TEMPLATE_DIR = BASE_DIR / "templates"

# Share resolved path with export blueprint
os.environ["RF_SCANNER_DB"] = str(DB_PATH)

# ── Flask app ─────────────────────────────────────────────────────────────────
app = Flask(__name__, static_folder=str(STATIC_DIR), template_folder=str(TEMPLATE_DIR))
CORS(app)
app.register_blueprint(export_bp)


# ── Schema bootstrap ──────────────────────────────────────────────────────────
def init_db_schema():
    """Create all tables on first run. Safe to call on an existing database."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS scan_sessions (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp     TEXT    NOT NULL,
            latitude      REAL, longitude REAL, altitude_m REAL,
            gps_quality   INTEGER, hdop REAL,
            noise_mean    REAL, noise_std REAL, noise_median REAL,
            noise_n       INTEGER, session_label TEXT
        );
        CREATE TABLE IF NOT EXISTS frequency_measurements (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id     INTEGER NOT NULL REFERENCES scan_sessions(id),
            frequency_hz   REAL    NOT NULL,
            amplitude_dbm  REAL    NOT NULL,
            snr_db         REAL,
            is_outlier     INTEGER DEFAULT 0,
            outlier_reason TEXT
        );
        CREATE TABLE IF NOT EXISTS noise_samples (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id     INTEGER NOT NULL REFERENCES scan_sessions(id),
            frequency_hz   REAL    NOT NULL,
            amplitude_dbm  REAL    NOT NULL,
            is_outlier     INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS overlay_layers (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT    NOT NULL,
            color      TEXT    NOT NULL DEFAULT '#f0a500',
            type       TEXT    NOT NULL DEFAULT 'drawn',
            source     TEXT,
            visible    INTEGER NOT NULL DEFAULT 1,
            created_at TEXT    NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS overlay_items (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            layer_id    INTEGER NOT NULL REFERENCES overlay_layers(id) ON DELETE CASCADE,
            item_type   TEXT    NOT NULL,
            name        TEXT,
            description TEXT,
            color       TEXT,
            geometry    TEXT    NOT NULL,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_fm_session ON frequency_measurements(session_id);
        CREATE INDEX IF NOT EXISTS idx_ns_session ON noise_samples(session_id);
        CREATE INDEX IF NOT EXISTS idx_ss_time    ON scan_sessions(timestamp);
        CREATE INDEX IF NOT EXISTS idx_oi_layer   ON overlay_items(layer_id);
    """)
    conn.commit()
    conn.close()


# ── DB helper ─────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def row_to_dict(row):
    return dict(row) if row else None


# ── API routes ────────────────────────────────────────────────────────────────

@app.route("/api/status")
def api_status():
    try:
        db = get_db()
        latest    = db.execute("SELECT * FROM scan_sessions ORDER BY id DESC LIMIT 1").fetchone()
        n_sessions = db.execute("SELECT COUNT(*) FROM scan_sessions").fetchone()[0]
        n_meas    = db.execute("SELECT COUNT(*) FROM frequency_measurements").fetchone()[0]
        return jsonify({
            "status": "ok",
            "n_sessions": n_sessions,
            "n_measurements": n_meas,
            "latest_session": row_to_dict(latest),
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/frequencies")
def api_frequencies():
    db = get_db()
    rows = db.execute(
        "SELECT DISTINCT frequency_hz FROM frequency_measurements ORDER BY frequency_hz"
    ).fetchall()
    return jsonify([r["frequency_hz"] for r in rows])


@app.route("/api/sessions")
def api_sessions():
    limit = min(int(request.args.get("limit", 200)), 1000)
    db = get_db()
    rows = db.execute(
        "SELECT * FROM scan_sessions ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    return jsonify([row_to_dict(r) for r in rows])


@app.route("/api/heatmap/average")
def api_heatmap_average():
    mode = request.args.get("mode", "amplitude")
    db   = get_db()
    agg  = "AVG(m.snr_db)" if mode == "snr" else "AVG(m.amplitude_dbm)"
    rows = db.execute(f"""
        SELECT s.latitude, s.longitude, s.timestamp,
               {agg} AS value, s.noise_mean
        FROM scan_sessions s
        JOIN frequency_measurements m ON m.session_id = s.id
        WHERE s.latitude IS NOT NULL AND s.longitude IS NOT NULL
        GROUP BY s.id ORDER BY s.timestamp
    """).fetchall()

    features = []
    for r in rows:
        if r["value"] is None:
            continue
        features.append({
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [r["longitude"], r["latitude"]]},
            "properties": {
                "value": round(r["value"], 2),
                "mode": mode,
                "timestamp": r["timestamp"],
                "noise_floor": r["noise_mean"],
            }
        })
    return jsonify({"type": "FeatureCollection", "features": features})


@app.route("/api/heatmap/frequency/<int:freq_hz>")
def api_heatmap_frequency(freq_hz):
    mode = request.args.get("mode", "amplitude")
    tol  = 50_000
    db   = get_db()
    col  = "m.snr_db" if mode == "snr" else "m.amplitude_dbm"
    rows = db.execute(f"""
        SELECT s.latitude, s.longitude, s.timestamp,
               {col} AS value, m.is_outlier, s.noise_mean
        FROM scan_sessions s
        JOIN frequency_measurements m ON m.session_id = s.id
        WHERE s.latitude IS NOT NULL AND s.longitude IS NOT NULL
          AND m.frequency_hz BETWEEN ? AND ?
        ORDER BY s.timestamp
    """, (freq_hz - tol, freq_hz + tol)).fetchall()

    features = []
    for r in rows:
        if r["value"] is None:
            continue
        features.append({
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [r["longitude"], r["latitude"]]},
            "properties": {
                "value": round(r["value"], 2),
                "mode": mode,
                "is_outlier": bool(r["is_outlier"]),
                "timestamp": r["timestamp"],
                "noise_floor": r["noise_mean"],
                "frequency_hz": freq_hz,
            }
        })
    return jsonify({"type": "FeatureCollection", "features": features})


@app.route("/api/heatmap/filtered")
def api_heatmap_filtered():
    mode      = request.args.get("mode", "amplitude")
    date_from = request.args.get("date_from")
    date_to   = request.args.get("date_to")
    freq_hz   = request.args.get("freq_hz", type=int)
    label     = request.args.get("label")
    tol       = 50_000

    db = get_db()
    where  = ["s.latitude IS NOT NULL", "s.longitude IS NOT NULL"]
    params = []

    if date_from:
        where.append("s.timestamp >= ?"); params.append(date_from)
    if date_to:
        where.append("s.timestamp <= ?"); params.append(date_to + "T23:59:59")
    if freq_hz:
        where.append("m.frequency_hz BETWEEN ? AND ?")
        params += [freq_hz - tol, freq_hz + tol]
    if label:
        where.append("s.session_label LIKE ?"); params.append(f"%{label}%")

    agg = "m.snr_db" if mode == "snr" else "m.amplitude_dbm"
    rows = db.execute(f"""
        SELECT s.latitude, s.longitude, s.timestamp, s.noise_mean,
               AVG({agg}) AS value,
               COUNT(m.id) AS n_meas,
               SUM(m.is_outlier) AS n_alerts
        FROM scan_sessions s
        JOIN frequency_measurements m ON m.session_id = s.id
        WHERE {' AND '.join(where)}
        GROUP BY s.id ORDER BY s.timestamp
    """, params).fetchall()

    features = []
    for r in rows:
        if r["value"] is None:
            continue
        features.append({
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [r["longitude"], r["latitude"]]},
            "properties": {
                "value": round(r["value"], 2),
                "mode": mode,
                "timestamp": r["timestamp"],
                "noise_floor": r["noise_mean"],
                "n_meas": r["n_meas"],
                "n_alerts": r["n_alerts"],
            }
        })
    return jsonify({"type": "FeatureCollection", "features": features})


@app.route("/api/sessions/<int:session_id>/detail")
def api_session_detail(session_id):
    db = get_db()
    session = db.execute("SELECT * FROM scan_sessions WHERE id=?", (session_id,)).fetchone()
    if not session:
        abort(404)
    measurements = db.execute(
        "SELECT * FROM frequency_measurements WHERE session_id=? ORDER BY frequency_hz",
        (session_id,)
    ).fetchall()
    noise_samples = db.execute(
        "SELECT * FROM noise_samples WHERE session_id=? ORDER BY frequency_hz",
        (session_id,)
    ).fetchall()
    return jsonify({
        "session": row_to_dict(session),
        "measurements": [row_to_dict(m) for m in measurements],
        "noise_samples": [row_to_dict(n) for n in noise_samples],
    })


@app.route("/api/stats/frequency/<int:freq_hz>")
def api_freq_stats(freq_hz):
    tol  = 50_000
    db   = get_db()
    rows = db.execute("""
        SELECT m.amplitude_dbm, m.snr_db, m.is_outlier, s.timestamp
        FROM frequency_measurements m
        JOIN scan_sessions s ON s.id = m.session_id
        WHERE m.frequency_hz BETWEEN ? AND ?
        ORDER BY s.timestamp
    """, (freq_hz - tol, freq_hz + tol)).fetchall()

    amps = [r["amplitude_dbm"] for r in rows if not r["is_outlier"]]
    snrs = [r["snr_db"] for r in rows if r["snr_db"] is not None and not r["is_outlier"]]

    def safe_stats(values):
        if not values:
            return {}
        return {
            "min":    round(min(values), 2),
            "max":    round(max(values), 2),
            "mean":   round(statistics.mean(values), 2),
            "median": round(statistics.median(values), 2),
            "std":    round(statistics.stdev(values), 2) if len(values) > 1 else 0,
            "n":      len(values),
        }

    return jsonify({
        "frequency_hz":    freq_hz,
        "amplitude_dbm":   safe_stats(amps),
        "snr_db":          safe_stats(snrs),
        "total_readings":  len(rows),
        "outlier_count":   sum(1 for r in rows if r["is_outlier"]),
        "timeseries": [
            {"t": r["timestamp"], "amp": r["amplitude_dbm"], "snr": r["snr_db"]}
            for r in rows
        ],
    })


# ── Overlay API ───────────────────────────────────────────────────────────────

@app.route("/api/overlays")
def api_overlays_list():
    db = get_db()
    layers = db.execute("SELECT * FROM overlay_layers ORDER BY id").fetchall()
    result = []
    for layer in layers:
        items = db.execute(
            "SELECT * FROM overlay_items WHERE layer_id=? ORDER BY id",
            (layer["id"],)
        ).fetchall()
        d = row_to_dict(layer)
        d["items"] = []
        for item in items:
            i = row_to_dict(item)
            try:
                i["geometry"] = json.loads(i["geometry"])
            except Exception:
                i["geometry"] = {}
            d["items"].append(i)
        result.append(d)
    return jsonify(result)


@app.route("/api/overlays/layer", methods=["POST"])
def api_overlay_layer_create():
    data = request.get_json(force=True, silent=True) or {}
    if not data.get("name"):
        abort(400)
    db = get_db()
    cur = db.cursor()
    cur.execute(
        "INSERT INTO overlay_layers (name, color, type, source, visible) VALUES (?,?,?,?,?)",
        (data["name"], data.get("color","#f0a500"),
         data.get("type","drawn"), data.get("source"),
         1 if data.get("visible", True) else 0)
    )
    db.commit()
    row = db.execute("SELECT * FROM overlay_layers WHERE id=?", (cur.lastrowid,)).fetchone()
    return jsonify(row_to_dict(row)), 201


@app.route("/api/overlays/layer/<int:layer_id>", methods=["PATCH"])
def api_overlay_layer_update(layer_id):
    data = request.get_json(force=True, silent=True) or {}
    db = get_db()
    if not db.execute("SELECT id FROM overlay_layers WHERE id=?", (layer_id,)).fetchone():
        abort(404)
    fields, vals = [], []
    for col in ("name","color","visible"):
        if col in data:
            fields.append(f"{col}=?"); vals.append(data[col])
    if fields:
        vals.append(layer_id)
        db.execute(f"UPDATE overlay_layers SET {','.join(fields)} WHERE id=?", vals)
        db.commit()
    return jsonify(row_to_dict(db.execute("SELECT * FROM overlay_layers WHERE id=?", (layer_id,)).fetchone()))


@app.route("/api/overlays/layer/<int:layer_id>", methods=["DELETE"])
def api_overlay_layer_delete(layer_id):
    db = get_db()
    db.execute("DELETE FROM overlay_layers WHERE id=?", (layer_id,))
    db.commit()
    return jsonify({"deleted": layer_id})


@app.route("/api/overlays/item", methods=["POST"])
def api_overlay_item_create():
    data = request.get_json(force=True, silent=True) or {}
    if not data.get("layer_id") or not data.get("item_type") or not data.get("geometry"):
        abort(400)
    db = get_db()
    if not db.execute("SELECT id FROM overlay_layers WHERE id=?", (data["layer_id"],)).fetchone():
        abort(404)
    cur = db.cursor()
    cur.execute(
        "INSERT INTO overlay_items (layer_id,item_type,name,description,color,geometry) VALUES (?,?,?,?,?,?)",
        (data["layer_id"], data["item_type"], data.get("name"),
         data.get("description"), data.get("color"),
         json.dumps(data["geometry"]))
    )
    db.commit()
    row = db.execute("SELECT * FROM overlay_items WHERE id=?", (cur.lastrowid,)).fetchone()
    d = row_to_dict(row)
    d["geometry"] = json.loads(d["geometry"])
    return jsonify(d), 201


@app.route("/api/overlays/item/<int:item_id>", methods=["PATCH"])
def api_overlay_item_update(item_id):
    data = request.get_json(force=True, silent=True) or {}
    db = get_db()
    if not db.execute("SELECT id FROM overlay_items WHERE id=?", (item_id,)).fetchone():
        abort(404)
    fields, vals = [], []
    for col in ("name","description","color"):
        if col in data:
            fields.append(f"{col}=?"); vals.append(data[col])
    if fields:
        vals.append(item_id)
        db.execute(f"UPDATE overlay_items SET {','.join(fields)} WHERE id=?", vals)
        db.commit()
    row = db.execute("SELECT * FROM overlay_items WHERE id=?", (item_id,)).fetchone()
    d = row_to_dict(row)
    d["geometry"] = json.loads(d["geometry"])
    return jsonify(d)


@app.route("/api/overlays/item/<int:item_id>", methods=["DELETE"])
def api_overlay_item_delete(item_id):
    db = get_db()
    db.execute("DELETE FROM overlay_items WHERE id=?", (item_id,))
    db.commit()
    return jsonify({"deleted": item_id})


@app.route("/api/alerts/recent")
def api_alerts_recent():
    since = request.args.get("since_session", type=int)
    limit = min(int(request.args.get("limit", 50)), 200)
    db    = get_db()
    if since:
        rows = db.execute("""
            SELECT m.frequency_hz, m.amplitude_dbm, m.snr_db, m.outlier_reason,
                   s.id AS session_id, s.timestamp, s.latitude, s.longitude, s.session_label
            FROM frequency_measurements m
            JOIN scan_sessions s ON s.id = m.session_id
            WHERE m.is_outlier=1 AND s.id > ?
            ORDER BY s.id DESC LIMIT ?
        """, (since, limit)).fetchall()
    else:
        rows = db.execute("""
            SELECT m.frequency_hz, m.amplitude_dbm, m.snr_db, m.outlier_reason,
                   s.id AS session_id, s.timestamp, s.latitude, s.longitude, s.session_label
            FROM frequency_measurements m
            JOIN scan_sessions s ON s.id = m.session_id
            WHERE m.is_outlier=1
              AND s.id >= (SELECT COALESCE(MAX(id)-4, 0) FROM scan_sessions)
            ORDER BY s.id DESC LIMIT ?
        """, (limit,)).fetchall()
    return jsonify([row_to_dict(r) for r in rows])


# ── Static / UI ───────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory(str(TEMPLATE_DIR), "index.html")


@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(str(STATIC_DIR), filename)


@app.errorhandler(404)
def not_found(e):
    if not request.path.startswith("/api/"):
        return send_from_directory(str(TEMPLATE_DIR), "index.html")
    return jsonify({"error": "not found", "path": request.path}), 404


@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "internal server error", "detail": str(e)}), 500


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="RF Scanner Web Server")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    print(f"DB path      : {DB_PATH}")
    print(f"Static dir   : {STATIC_DIR}")
    print(f"Template dir : {TEMPLATE_DIR}")

    # Init schema before serving anything
    init_db_schema()
    print(f"Schema ready : {DB_PATH}")
    print(f"Starting     : http://{args.host}:{args.port}")
    app.run(host=args.host, port=args.port, debug=args.debug)
