#!/usr/bin/env python3
"""
Seed script — generates realistic demo scan data for development/testing.
Run this on the Pi (or any machine) to populate the database with
a multi-day, multi-location dataset you can visualise immediately.

Usage:
  python3 seed.py                          # uses default DB path
  python3 seed.py --db /path/to/scans.db  # explicit path
  python3 seed.py --sessions 40           # fewer sessions (faster)
"""

import argparse
import math
import random
import sqlite3
import statistics
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

# ── DB path: prefer explicit arg, then env var, then sensible default ─────────
DEFAULT_DB = Path("/home/pi/rf_scanner/data/scans.db")

# Leesburg, VA area bounding box
LAT_C, LON_C = 39.1157, -77.5636
SPREAD = 0.04   # ~4 km

TARGET_FREQS = [
    88_100_000,
    100_300_000,
    162_400_000,
    433_920_000,
    462_562_500,
    915_000_000,
    1_090_000_000,
]

SIGNAL_SOURCES = {
    88_100_000:    [(39.113, -77.558, -55), (39.118, -77.570, -60)],
    100_300_000:   [(39.120, -77.550, -52), (39.115, -77.555, -58)],
    162_400_000:   [(39.108, -77.562, -65)],
    1_090_000_000: [(39.116, -77.548, -72), (39.122, -77.535, -68)],
}

NOISE_FLOOR_BASE = -96.0
NOISE_STD_BASE   = 2.5


def create_tables(conn: sqlite3.Connection) -> None:
    """Create all tables — safe to call on an existing database (IF NOT EXISTS)."""
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS scan_sessions (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp    TEXT    NOT NULL,
            latitude     REAL,
            longitude    REAL,
            altitude_m   REAL,
            gps_quality  INTEGER,
            hdop         REAL,
            noise_mean   REAL,
            noise_std    REAL,
            noise_median REAL,
            noise_n      INTEGER,
            session_label TEXT
        );

        CREATE TABLE IF NOT EXISTS frequency_measurements (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id    INTEGER NOT NULL REFERENCES scan_sessions(id),
            frequency_hz  REAL    NOT NULL,
            amplitude_dbm REAL    NOT NULL,
            snr_db        REAL,
            is_outlier    INTEGER DEFAULT 0,
            outlier_reason TEXT
        );

        CREATE TABLE IF NOT EXISTS noise_samples (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id    INTEGER NOT NULL REFERENCES scan_sessions(id),
            frequency_hz  REAL    NOT NULL,
            amplitude_dbm REAL    NOT NULL,
            is_outlier    INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS overlay_layers (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT    NOT NULL,
            color      TEXT    NOT NULL DEFAULT '#f0a500',
            type       TEXT    NOT NULL DEFAULT 'drawn',
            source     TEXT,
            visible    INTEGER NOT NULL DEFAULT 1,
            created_at TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS overlay_items (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            layer_id    INTEGER NOT NULL REFERENCES overlay_layers(id) ON DELETE CASCADE,
            item_type   TEXT    NOT NULL,
            name        TEXT,
            description TEXT,
            color       TEXT,
            geometry    TEXT    NOT NULL,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_fm_session  ON frequency_measurements(session_id);
        CREATE INDEX IF NOT EXISTS idx_ns_session  ON noise_samples(session_id);
        CREATE INDEX IF NOT EXISTS idx_ss_time     ON scan_sessions(timestamp);
        CREATE INDEX IF NOT EXISTS idx_oi_layer    ON overlay_items(layer_id);
    """)
    conn.commit()


def distance_km(lat1, lon1, lat2, lon2):
    dlat = (lat2 - lat1) * 111.0
    dlon = (lon2 - lon1) * 111.0 * math.cos(math.radians(lat1))
    return math.sqrt(dlat**2 + dlon**2)


def model_amplitude(freq_hz, lat, lon, noise_floor, time_of_day):
    sources = SIGNAL_SOURCES.get(freq_hz, [])
    max_amp = None
    for src_lat, src_lon, src_power in sources:
        d = max(distance_km(lat, lon, src_lat, src_lon), 0.1)
        fspl_db = 20 * math.log10(d) + 20 * math.log10(freq_hz / 1e6) + 32.45
        amp = src_power - fspl_db + random.gauss(0, 2.5)
        if max_amp is None or amp > max_amp:
            max_amp = amp
    tod_offset = 3 * math.sin(2 * math.pi * time_of_day / 24)
    base = max_amp if max_amp is not None else noise_floor + random.gauss(2, 1)
    return min(base + tod_offset + random.gauss(0, 1.5), -20.0)


def gen_noise_samples(freq_min, freq_max, target_freqs, noise_floor, n=30):
    samples = []
    attempts = 0
    while len(samples) < n and attempts < n * 20:
        attempts += 1
        f = random.uniform(freq_min, freq_max)
        if any(abs(f - t) < 500_000 for t in target_freqs):
            continue
        amp = (noise_floor + random.uniform(8, 15)
               if random.random() < 0.05
               else noise_floor + random.gauss(0, NOISE_STD_BASE))
        samples.append((f, amp))
    return samples


def iqr_clean(values):
    if len(values) < 4:
        return list(values), []
    q1 = statistics.quantiles(values, n=4)[0]
    q3 = statistics.quantiles(values, n=4)[2]
    iqr = q3 - q1
    lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    return ([v for v in values if lo <= v <= hi],
            [v for v in values if v < lo or v > hi])


def clear_existing(conn):
    """Wipe previous seed data so re-seeding is idempotent."""
    conn.execute("DELETE FROM overlay_items")
    conn.execute("DELETE FROM overlay_layers")
    conn.execute("DELETE FROM noise_samples")
    conn.execute("DELETE FROM frequency_measurements")
    conn.execute("DELETE FROM scan_sessions")
    conn.commit()


def seed(db_path: Path, n_sessions: int = 80) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")  # safer for concurrent access
    conn.execute("PRAGMA foreign_keys=ON")

    print(f"Database : {db_path}")
    create_tables(conn)
    clear_existing(conn)

    print(f"Seeding  : {n_sessions} sessions across 7 days…")
    base_time = datetime.now(timezone.utc) - timedelta(days=7)
    theta = 0.0
    lat, lon = LAT_C, LON_C

    for i in range(n_sessions):
        theta += random.uniform(-0.3, 0.5)
        lat += math.cos(theta) * random.uniform(0.0005, 0.002)
        lon += math.sin(theta) * random.uniform(0.0005, 0.002)
        lat = max(LAT_C - SPREAD, min(LAT_C + SPREAD, lat))
        lon = max(LON_C - SPREAD, min(LON_C + SPREAD, lon))

        scan_time = base_time + timedelta(hours=i * 2.1)
        ts  = scan_time.isoformat()
        tod = scan_time.hour

        nf_base = NOISE_FLOOR_BASE + random.gauss(0, 1.5)
        noise_samples = gen_noise_samples(
            min(TARGET_FREQS), max(TARGET_FREQS), TARGET_FREQS, nf_base
        )
        if not noise_samples:
            print(f"  [WARN] session {i}: could not generate noise samples, skipping")
            continue

        raw_amps = [a for _, a in noise_samples]
        clean, outliers_list = iqr_clean(raw_amps)
        if not clean:
            clean = raw_amps

        noise_mean   = statistics.mean(clean)
        noise_std    = statistics.stdev(clean) if len(clean) > 1 else 1.5
        noise_median = statistics.median(clean)

        cur = conn.cursor()
        cur.execute("""
            INSERT INTO scan_sessions
              (timestamp, latitude, longitude, altitude_m, gps_quality, hdop,
               noise_mean, noise_std, noise_median, noise_n, session_label)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """, (ts, lat, lon,
              round(120.0 + random.gauss(0, 5), 1),
              1,
              round(random.uniform(0.9, 2.2), 1),
              round(noise_mean, 3),
              round(noise_std, 3),
              round(noise_median, 3),
              len(clean),
              f"survey_day_{i // 10 + 1}"))
        session_id = cur.lastrowid

        outliers_set = set(outliers_list)
        for nf, na in noise_samples:
            cur.execute(
                "INSERT INTO noise_samples (session_id, frequency_hz, amplitude_dbm, is_outlier) VALUES (?,?,?,?)",
                (session_id, round(nf, 0), round(na, 3), 1 if na in outliers_set else 0)
            )

        for freq in TARGET_FREQS:
            amp = model_amplitude(freq, lat, lon, noise_mean, tod)
            snr = amp - noise_mean
            is_outlier = 1 if snr > 15 else 0
            cur.execute("""
                INSERT INTO frequency_measurements
                  (session_id, frequency_hz, amplitude_dbm, snr_db, is_outlier, outlier_reason)
                VALUES (?,?,?,?,?,?)
            """, (session_id, freq,
                  round(amp, 2), round(snr, 2),
                  is_outlier,
                  ">2.5σ above noise floor" if is_outlier else None))

        conn.commit()
        if i % 10 == 0:
            print(f"  {i + 1}/{n_sessions} sessions written…")

    # ── Verify ────────────────────────────────────────────────────────────────
    n_sess = conn.execute("SELECT COUNT(*) FROM scan_sessions").fetchone()[0]
    n_meas = conn.execute("SELECT COUNT(*) FROM frequency_measurements").fetchone()[0]
    n_ns   = conn.execute("SELECT COUNT(*) FROM noise_samples").fetchone()[0]

    print()
    print("✓ Seed complete")
    print(f"  Sessions         : {n_sess}")
    print(f"  Measurements     : {n_meas}")
    print(f"  Noise samples    : {n_ns}")
    print(f"  Database         : {db_path}")
    conn.close()


def main():
    parser = argparse.ArgumentParser(description="RF Scanner — seed demo data")
    parser.add_argument("--db",       default=str(DEFAULT_DB),
                        help=f"Path to SQLite database (default: {DEFAULT_DB})")
    parser.add_argument("--sessions", type=int, default=80,
                        help="Number of scan sessions to generate (default: 80)")
    args = parser.parse_args()

    db_path = Path(args.db)
    try:
        seed(db_path, args.sessions)
    except KeyboardInterrupt:
        print("\nSeed interrupted by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Seed failed: {e}", file=sys.stderr)
        import traceback; traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
